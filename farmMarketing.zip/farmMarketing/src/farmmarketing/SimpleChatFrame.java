/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;

/**
 *
 * @author sneha
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SimpleChatFrame extends JFrame {
    private JTextArea chatArea;
    private JTextField messageField;
    private JButton sendButton;
    private JComboBox<String> identityComboBox;

    public SimpleChatFrame() {
        super("Simple Chat");
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Create chat area
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        // Create input field and send button
        messageField = new JTextField();
        sendButton = new JButton("Send");
        
        // Create identity selection combo box
        identityComboBox = new JComboBox<>(new String[] { "Farmer", "Customer" });
        
        // Panel for input field, identity combo box, and send button
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(identityComboBox, BorderLayout.WEST);
        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        // Add components to the frame
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        // Send button action
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });

        // Send message when Enter key is pressed
        messageField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });

        // Frame settings
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void sendMessage() {
        String message = messageField.getText().trim();
        String identity = (String) identityComboBox.getSelectedItem();

        if (!message.isEmpty()) {
            chatArea.append(identity + ": " + message + "\n");
            messageField.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SimpleChatFrame());
    }
}

