/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;

/**
 *
 * @author sneha
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

// Alert class to represent alerts
class Alert {
    private String type;
    private String message;
    private boolean viewed;

    public Alert(String type, String message) {
        this.type = type;
        this.message = message;
        this.viewed = false;
    }

    public String getType() {
        return type;
    }

    public String getMessage() {
        return message;
    }

    public boolean isViewed() {
        return viewed;
    }

    public void markAsViewed() {
        this.viewed = true;
    }
}

// User class to store alerts for a user
class User {
    private List<Alert> alerts;

    public User() {
        this.alerts = new ArrayList<>();
    }

    public void addAlert(Alert alert) {
        alerts.add(alert);
    }

    public List<Alert> getAlerts() {
        return alerts;
    }
}

// Main application class
public class ContractFarmingAlertsApp extends JFrame {
    private User user;
    private JTextArea alertArea;
    private JButton triggerAlertButton;

    public ContractFarmingAlertsApp() {
        user = new User();
        setupUI();
        startAlertChecking();
    }

    private void setupUI() {
        setTitle("Contract Farming Alerts");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        alertArea = new JTextArea();
        alertArea.setEditable(false);
        add(new JScrollPane(alertArea), BorderLayout.CENTER);

        triggerAlertButton = new JButton("Trigger Sample Alert");
        triggerAlertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Sample alert triggering
                user.addAlert(new Alert("New Contract", "A new contract for crop farming is available."));
                user.addAlert(new Alert("Contract Expiration", "Your contract for Mango is expiring soon."));
                displayAlerts();
            }
        });
        add(triggerAlertButton, BorderLayout.SOUTH);
    }

    private void displayAlerts() {
        StringBuilder alertMessages = new StringBuilder();
        for (Alert alert : user.getAlerts()) {
            if (!alert.isViewed()) {
                alertMessages.append(alert.getMessage()).append("\n");
                alert.markAsViewed(); // Mark alert as viewed after displaying
            }
        }
        alertArea.setText(alertMessages.toString());
        if (alertMessages.length() > 0) {
            JOptionPane.showMessageDialog(this, alertMessages.toString(), "Notifications", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void startAlertChecking() {
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(60000); // Check for alerts every minute
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                displayAlerts();
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ContractFarmingAlertsApp app = new ContractFarmingAlertsApp();
            app.setVisible(true);
        });
    }
}
