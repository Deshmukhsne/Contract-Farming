/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

public class AdvancedOptionBasedChatBot extends JFrame {

    private JPanel chatPanel;
    private JPanel optionsPanel;
    private JScrollPane scrollPane;

    public AdvancedOptionBasedChatBot() {
        setTitle("Advanced Option-Based ChatBot");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Chat area panel with vertical layout for chat bubbles
        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        chatPanel.setBackground(Color.WHITE);
        
        scrollPane = new JScrollPane(chatPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        // Options panel
        optionsPanel = new JPanel();
        optionsPanel.setLayout(new GridLayout(2, 1, 5, 5));
        optionsPanel.setBackground(Color.WHITE);
        optionsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(optionsPanel, BorderLayout.SOUTH);

        // Starting conversation
        displayBotMessage("Welcome! How can I help you?");
        addOption("I have an issue", "No issue");

        setVisible(true);
    }

    private void displayBotMessage(String message) {
        displayMessage("Bot", message, new Color(70, 70, 70),"C:/Users/sneha/Downloads/bot image.png"); // Replace with actual path
    }

    private void displayUserMessage(String message) {
        displayMessage("You", message, new Color(0, 100, 0),"C:/Users/sneha/Downloads/user image.png"); // Replace with actual path
    }

    private void displayMessage(String sender, String message, Color bubbleColor, String iconPath) {
        JPanel messagePanel = new JPanel();
        messagePanel.setLayout(new BorderLayout(10, 10));
        messagePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        messagePanel.setBackground(Color.WHITE);

        // Icon
        JLabel iconLabel = new JLabel(new ImageIcon(iconPath));
        
        // Bubble
        JTextArea messageLabel = new JTextArea(message);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        messageLabel.setLineWrap(true);
        messageLabel.setWrapStyleWord(true);
        messageLabel.setOpaque(true);
        messageLabel.setBackground(bubbleColor);
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        messageLabel.setEditable(false);

        if (sender.equals("Bot")) {
            messagePanel.add(iconLabel, BorderLayout.WEST);
            messagePanel.add(messageLabel, BorderLayout.CENTER);
        } else {
            messagePanel.add(messageLabel, BorderLayout.CENTER);
            messagePanel.add(iconLabel, BorderLayout.EAST);
        }

        // Add message panel to chat panel
        chatPanel.add(messagePanel);
        chatPanel.revalidate();
        chatPanel.repaint();

        // Scroll to bottom with slight delay for animation effect
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum()));
            }
        }, 100);
    }

    private void addOption(String option1, String option2) {
        optionsPanel.removeAll();

        JButton btnOption1 = createOptionButton(option1);
        JButton btnOption2 = createOptionButton(option2);

        btnOption1.addActionListener(new OptionListener(option1));
        btnOption2.addActionListener(new OptionListener(option2));

        optionsPanel.add(btnOption1);
        optionsPanel.add(btnOption2);

        optionsPanel.revalidate();
        optionsPanel.repaint();
    }

    private JButton createOptionButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return button;
    }

    private class OptionListener implements ActionListener {
        private String selectedOption;

        public OptionListener(String option) {
            this.selectedOption = option;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            displayUserMessage(selectedOption);

            // Simple response logic based on selected option
            if (selectedOption.equals("I have an issue")) {
                displayBotMessage("Can you specify the type of issue?");
                addOption("Technical issue", "Billing issue");
            } else if (selectedOption.equals("Technical issue")) {
                displayBotMessage("Please choose the technical area.");
                addOption("Software", "Hardware");
            } else if (selectedOption.equals("Billing issue")) {
                displayBotMessage("For billing, please contact support.");
                addOption("Back to start", "Exit");
            } else if (selectedOption.equals("No issue") || selectedOption.equals("Exit")) {
                displayBotMessage("Thank you! Have a great day!");
                addOption("Restart", "Close");
            } else if (selectedOption.equals("Back to start")) {
                displayBotMessage("Welcome! How can I help you?");
                addOption("I have an issue", "No issue");
            } else if (selectedOption.equals("Software")) {
                displayBotMessage("Please check your software updates.");
                addOption("Back to start", "Exit");
            } else if (selectedOption.equals("Hardware")) {
                displayBotMessage("Please ensure your device is connected properly.");
                addOption("Back to start", "Exit");
            } else if (selectedOption.equals("Restart")) {
                displayBotMessage("Restarting...");
                addOption("I have an issue", "No issue");
            } else if (selectedOption.equals("Close")) {
                System.exit(0);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdvancedOptionBasedChatBot::new);
    }
}
