/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;

/**
 *
 * @author sneha
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import weka.classifiers.functions.LinearRegression;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.instance.RemoveWithValues;

public class CropPricePredictionApp1 extends JFrame {

    private Instances dataset;
    private LinearRegression model;
    private JTextArea resultArea;
    private JButton loadButton, predictButton;
    private JTextField itemField, yearField;

    public CropPricePredictionApp1() {
        setTitle("Crop Price Prediction");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create components
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        loadButton = new JButton("Load CSV");
        loadButton.addActionListener(new LoadButtonListener());

        predictButton = new JButton("Predict Price");
        predictButton.addActionListener(new PredictButtonListener());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2));
        inputPanel.add(new JLabel("Item:"));
        itemField = new JTextField();
        inputPanel.add(itemField);
        inputPanel.add(new JLabel("Year:"));
        yearField = new JTextField();
        inputPanel.add(yearField);
        inputPanel.add(loadButton);
        inputPanel.add(predictButton);

        // Add components to the frame
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.NORTH);
    }

    private class LoadButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                try {
                    loadCSVData(selectedFile.getAbsolutePath());
                    resultArea.setText("Data loaded successfully.\n");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    resultArea.setText("Error loading data: " + ex.getMessage());
                }
            }
        }
    }

    private class PredictButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String item = itemField.getText().trim();
                String year = yearField.getText().trim();

                if (item.isEmpty() || year.isEmpty()) {
                    resultArea.setText("Please enter both item and year.");
                    return;
                }

                Instances filteredData = filterDataset(item, year);
                if (filteredData.numInstances() == 0) {
                    resultArea.setText("No data found for the specified item and year.");
                    return;
                }

                trainModel(filteredData);
                predictPrices(filteredData);

            } catch (Exception ex) {
                ex.printStackTrace();
                resultArea.setText("Error: " + ex.getMessage());
            }
        }
    }

    private void loadCSVData(String filePath) throws Exception {
        CSVLoader loader = new CSVLoader();
        loader.setSource(new File(filePath));
        dataset = loader.getDataSet();

        // Set the last attribute (actual_price) as the class
        dataset.setClassIndex(dataset.numAttributes() - 1);
    }

    private Instances filterDataset(String item, String year) throws Exception {
        RemoveWithValues filter = new RemoveWithValues();
        filter.setInputFormat(dataset);

        // Apply filters based on item and year attributes
        // Assuming "Item" is attribute index 0 and "Year" is attribute index 1. Adjust as needed.
        filter.setAttributeIndex("first"); // First attribute is item
        filter.setNominalIndices(item); // Filter by item name
        filter.setModifyHeader(false);

        Instances filteredData = Filter.useFilter(dataset, filter);

        filter.setAttributeIndex("second"); // Second attribute is year
        filter.setNominalIndices(year); // Filter by year
        return Filter.useFilter(filteredData, filter);
    }

    private void trainModel(Instances data) throws Exception {
        model = new LinearRegression();
        model.buildClassifier(data);
        resultArea.append("Model trained successfully.\n");
    }

    private void predictPrices(Instances data) throws Exception {
        resultArea.append(String.format("%-20s %-20s %-20s\n", "Instance", "Actual Price", "Predicted Price"));
        resultArea.append("----------------------------------------------------------\n");

        for (int i = 0; i < data.numInstances(); i++) {
            Instance instance = data.instance(i);
            double actualPrice = instance.classValue();
            double predictedPrice = model.classifyInstance(instance);
            resultArea.append(String.format("%-20d %-20.2f %-20.2f\n", (i + 1), actualPrice, predictedPrice));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CropPricePredictionApp app = new CropPricePredictionApp();
            app.setVisible(true);
        });
    }
}
