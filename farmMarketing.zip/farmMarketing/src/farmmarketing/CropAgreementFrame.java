/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class CropAgreementFrame extends JFrame {

    private JTextField farmerNameField, farmLocationField, landAreaField, buyerNameField, cropTypeField, quantityField, priceField;
    private JTextArea agreementDetailsArea;

    public CropAgreementFrame() {
        setTitle("Crop Agreement Management");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(8, 2, 5, 5));

        // Farmer Fields
        inputPanel.add(new JLabel("Farmer Name:"));
        farmerNameField = new JTextField();
        inputPanel.add(farmerNameField);

        inputPanel.add(new JLabel("Farm Location:"));
        farmLocationField = new JTextField();
        inputPanel.add(farmLocationField);

        inputPanel.add(new JLabel("Land Area (acres):"));
        landAreaField = new JTextField();
        inputPanel.add(landAreaField);

        // Buyer Fields
        inputPanel.add(new JLabel("Buyer Name:"));
        buyerNameField = new JTextField();
        inputPanel.add(buyerNameField);

        // Crop Details
        inputPanel.add(new JLabel("Crop Type:"));
        cropTypeField = new JTextField();
        inputPanel.add(cropTypeField);

        inputPanel.add(new JLabel("Quantity (tons):"));
        quantityField = new JTextField();
        inputPanel.add(quantityField);

        inputPanel.add(new JLabel("Price per Ton (₹):"));
        priceField = new JTextField();
        inputPanel.add(priceField);

        // Display Area for Agreement Details
        agreementDetailsArea = new JTextArea(10, 40);
        agreementDetailsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(agreementDetailsArea);

        // Buttons
        JButton createAgreementButton = new JButton("Create Agreement");
        createAgreementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createAgreement();
            }
        });

       
        

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(createAgreementButton);
      

        // Adding to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void createAgreement() {
        String farmerName = farmerNameField.getText();
        String farmLocation = farmLocationField.getText();
        double landArea = Double.parseDouble(landAreaField.getText());
        String buyerName = buyerNameField.getText();
        String cropType = cropTypeField.getText();
        int quantity = Integer.parseInt(quantityField.getText());
        double price = Double.parseDouble(priceField.getText());
        double totalPrice = quantity * price;

        // Generate Agreement in Receipt Style
        String agreementText = String.format(
            "************ Crop Agreement Receipt ************\n" +
            "-----------------------------------------------\n" +
            "Farmer Name      : %-25s\n" +
            "Farm Location    : %-25s\n" +
            "Land Area        : %-6.2f acres\n" +
            "Buyer Name       : %-25s\n" +
            "Crop Type        : %-25s\n" +
            "Quantity         : %-6d tons\n" +
            "Price per Ton    : ₹ %-10.2f\n" +
            "-----------------------------------------------\n" +
            "Total Price      : ₹ %-10.2f\n" +
            "-----------------------------------------------\n" +
            "Thank you for choosing our platform!\n" +
            "************************************************\n\n",
            farmerName, farmLocation, landArea, buyerName, cropType, quantity, price, totalPrice
        );

        // Display the Agreement in the Text Area
        agreementDetailsArea.append(agreementText);
        
        // Clear the input fields
        clearFields();
    }

    private void clearFields() {
        farmerNameField.setText("");
        farmLocationField.setText("");
        landAreaField.setText("");
        buyerNameField.setText("");
        cropTypeField.setText("");
        quantityField.setText("");
        priceField.setText("");
    }

   
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CropAgreementFrame frame = new CropAgreementFrame();
            frame.setVisible(true);
        });
    }
}
