/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import weka.classifiers.functions.LinearRegression;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;

public class CropPricePredictionApp extends JFrame {

    private Instances dataset;
    private LinearRegression model;
    private JTextArea resultArea;
    private JButton loadButton, predictButton;
    private JTextField cropField, yearField;

    public CropPricePredictionApp() {
        // Set up the frame
        setTitle("Crop Price Prediction");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create components
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        loadButton = new JButton("Load CSV");
        loadButton.addActionListener(new LoadButtonListener());

        JLabel cropLabel = new JLabel("Crop Name:");
        cropField = new JTextField(10);
        
        JLabel yearLabel = new JLabel("Year:");
        yearField = new JTextField(5);

        predictButton = new JButton("Predict Price");
        predictButton.addActionListener(new PredictButtonListener());

        // Panel for inputs
        JPanel inputPanel = new JPanel();
        inputPanel.add(cropLabel);
        inputPanel.add(cropField);
        inputPanel.add(yearLabel);
        inputPanel.add(yearField);
        inputPanel.add(predictButton);

        // Add components to the frame
        add(scrollPane, BorderLayout.CENTER);
        add(loadButton, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.SOUTH);
    }

    private class LoadButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                try {
                    loadCSVData(selectedFile.getAbsolutePath());
                    resultArea.setText("Dataset loaded successfully.\n");
                } catch (Exception ex) {
                    ex.printStackTrace();
                    resultArea.setText("Error: " + ex.getMessage());
                }
            }
        }
    }

    private class PredictButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String cropName = cropField.getText().trim();
            String yearText = yearField.getText().trim();

            if (cropName.isEmpty() || yearText.isEmpty()) {
                resultArea.setText("Please enter both crop name and year.");
                return;
            }

            try {
                int year = Integer.parseInt(yearText);
                Instances filteredData = filterDatasetByCropAndYear(cropName, year);

                if (filteredData.isEmpty()) {
                    resultArea.setText("No data available for the specified crop and year.");
                    return;
                }

                trainModel(filteredData);
                predictPriceForYear(year);
            } catch (Exception ex) {
                ex.printStackTrace();
                resultArea.setText("Error: " + ex.getMessage());
            }
        }
    }

    private void loadCSVData(String filePath) throws Exception {
        CSVLoader loader = new CSVLoader();
        loader.setSource(new File(filePath));
        dataset = loader.getDataSet();
        dataset.setClassIndex(dataset.numAttributes() - 1); // Assuming last column is 'price'
    }

    private Instances filterDatasetByCropAndYear(String cropName, int year) {
        List<Instance> filteredInstances = new ArrayList<>();

        for (Instance instance : dataset) {
            String crop = instance.stringValue(dataset.attribute("crop_name"));
            int instanceYear = (int) instance.value(dataset.attribute("year"));

            if (crop.equalsIgnoreCase(cropName) && instanceYear < year) {
                filteredInstances.add(instance);
            }
        }

        Instances filteredData = new Instances(dataset, filteredInstances.size());
        for (Instance inst : filteredInstances) {
            filteredData.add(inst);
        }

        return filteredData;
    }

    private void trainModel(Instances filteredData) throws Exception {
        model = new LinearRegression();
        model.buildClassifier(filteredData);
        resultArea.append("Trained Linear Regression Model for specified crop.\n\n");
    }

    private void predictPriceForYear(int year) throws Exception {
        resultArea.append(String.format("%-20s %-20s\n", "Year", "Predicted Price"));
        resultArea.append("-----------------------------------------\n");

        // Creating a dummy instance for prediction
        Instance instance = (Instance) dataset.get(0).copy();
        instance.setValue(dataset.attribute("year"), year);

        double predictedPrice = model.classifyInstance(instance);
        resultArea.append(String.format("%-20d %-20.2f\n", year, predictedPrice));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CropPricePredictionApp app = new CropPricePredictionApp();
            app.setVisible(true);
        });
    }
}
